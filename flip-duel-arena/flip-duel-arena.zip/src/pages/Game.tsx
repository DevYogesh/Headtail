import Navbar from "@/components/layout/Navbar";
import CoinFlip from "@/components/game/CoinFlip";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/hooks/useAuth";
import { Navigate } from "react-router-dom";
import { useGameHistory } from "@/hooks/useGameHistory";
import { useOnlinePlayers } from "@/hooks/useOnlinePlayers";
import { useState } from "react";
import { useToast } from "@/components/ui/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const Game = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const { data: gameHistory, isLoading: loadingHistory, error: historyError } = useGameHistory();
  const { players: onlinePlayers, isLoading: loadingPlayers, error: playersError } = useOnlinePlayers();

  // Filter out the current user from the online players list
  const otherOnlinePlayers = onlinePlayers.filter(player => player.id !== user?.id);

  const handleCompete = (playerId: string, playerName: string) => {
    // For now, just show a toast notification
    toast({
      title: "Challenge sent",
      description: `You've challenged ${playerName} to a game!`,
    });
    
    // Here you would typically call a function to send the challenge
    // For example: sendChallenge(playerId);
  };

  if (!user) {
    return <Navigate to="/login" />;
  }

  return (
    <div className="min-h-screen bg-casino">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <Tabs defaultValue="coinflip">
              <TabsList className="w-full">
                <TabsTrigger value="coinflip" className="flex-1">
                  Coin Flip
                </TabsTrigger>
                <TabsTrigger value="leaderboard" className="flex-1">
                  Leaderboard
                </TabsTrigger>
              </TabsList>
              <TabsContent value="coinflip" className="mt-4">
                <Card className="border-casino-lighter bg-casino-lighter">
                  <CardContent className="p-6">
                    <CoinFlip />
                  </CardContent>
                </Card>
              </TabsContent>
              <TabsContent value="leaderboard" className="mt-4">
                {/* Leaderboard content remains the same */}
              </TabsContent>
            </Tabs>
          </div>

          <div>
            <Card className="border-casino-lighter bg-casino-lighter">
              <CardContent className="p-6">
                <h3 className="mb-4 text-xl font-bold text-casino-accent">Live Players</h3>
                <div className="rounded-lg bg-casino p-4">
                  {loadingPlayers ? (
                    <div className="flex justify-center py-6 text-casino-muted">Loading players...</div>
                  ) : playersError ? (
                    <div className="flex justify-center py-6 text-casino-red">Could not load players</div>
                  ) : otherOnlinePlayers.length > 0 ? (
                    <div className="space-y-3">
                      {otherOnlinePlayers.map((player) => (
                        <div
                          key={player.id}
                          className="flex items-center justify-between rounded border border-casino-lighter p-3 text-sm"
                        >
                          <div className="flex items-center space-x-3">
                            <Avatar className="h-8 w-8">
                              <AvatarImage src={player.avatar_url || ''} alt={player.name} />
                              <AvatarFallback className="bg-casino-accent text-casino-DEFAULT">
                                {player.name.substring(0, 2).toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium text-casino-text">{player.name}</div>
                              <div className="mt-1 text-xs text-casino-muted">
                                Online Player
                              </div>
                            </div>
                          </div>
                          <button
                            className="rounded bg-casino-accent px-3 py-1 text-xs font-medium text-casino-DEFAULT hover:bg-casino-accent/80"
                            onClick={() => handleCompete(player.id, player.name)}
                          >
                            Compete
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex justify-center py-6 text-casino-muted">
                      No other players online right now.
                    </div>
                  )}
                </div>

                <h3 className="mb-4 mt-6 text-xl font-bold text-casino-accent">Game History</h3>
                <div className="rounded-lg bg-casino p-4">
                  {loadingHistory ? (
                    <div className="flex justify-center py-6 text-casino-muted">Loading...</div>
                  ) : historyError ? (
                    <div className="flex justify-center py-6 text-casino-red">Could not load history</div>
                  ) : gameHistory && gameHistory.length > 0 ? (
                    <div className="space-y-3">
                      {gameHistory.map((game) => (
                        <div
                          key={game.id}
                          className="rounded border border-casino-lighter p-3 text-sm"
                        >
                          <div className="flex justify-between">
                            <span
                              className={
                                game.result === "win"
                                  ? "font-medium text-casino-green"
                                  : "font-medium text-casino-red"
                              }
                            >
                              {game.result === "win" ? "You Won" : "You Lost"}
                            </span>
                            <span className="text-casino-muted">{game.game_type}</span>
                          </div>
                          <div className="mt-1 flex justify-between text-xs">
                            <span className="text-casino-text">
                              {game.result === "win"
                                ? `+ $${game.amount}`
                                : `- $${game.amount}`}
                            </span>
                            <span className="text-casino-muted">
                              {new Date(game.created_at).toLocaleString()}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="flex justify-center py-6 text-casino-muted">
                      No game history found.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Game;
